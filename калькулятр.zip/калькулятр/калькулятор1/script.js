let currentNumber = "";
let previousNumber = "";
let operator = "";
let history = [];

function number(n) {
    currentNumber += n;
    document.getElementById("result").textContent = currentNumber;
}
function clearDisplay() {
    currentNumber = "";
    previousNumber = "";
    operator = "";
    document.getElementById("result").textContent = "0";
}
function chooseOperator(op) {
    if (currentNumber === "") return;
    previousNumber = currentNumber;
    operator = op;
    currentNumber = "";

    document.getElementById("history").textContent =
        previousNumber + " " + operator;
}
function calculate() {
    if (previousNumber === "" || currentNumber === "") return;
    let a = Number(previousNumber);
    let b = Number(currentNumber);
    let answer;

    if (operator === "+") {
        answer = a + b;
    } else if (operator === "-") {
        answer = a - b;
    } else if (operator === "*") {
        answer = a * b;
    } else if (operator === "/") {
        if (b === 0) {
            document.getElementById("result").textContent = "ERROR";
            return;
        }
        answer = a / b;
    } else {
        return;
    }
    let calculation =
        a + " " + operator + " " + b + " = " + answer;

    history.push(calculation);
    document.getElementById("history").textContent =
        calculation;

    currentNumber = String(answer);
    previousNumber = "";
    operator = "";
    document.getElementById("result").textContent =
        answer;
}
function decimal() {
    if (!currentNumber.includes(".")) {
        currentNumber += ".";
        document.getElementById("result").textContent =
            currentNumber;
    }
}
function deleteLast() {
    currentNumber = currentNumber.slice(0, -1);

    document.getElementById("result").textContent =
        currentNumber || "0";
}
function percent() {
    if (currentNumber === "") return;
    currentNumber = String(Number(currentNumber) / 100);

    document.getElementById("result").textContent =
        currentNumber;
}
function square() {
    if (currentNumber === "") return;

    currentNumber = String(Number(currentNumber) ** 2);

    document.getElementById("result").textContent =
        currentNumber;
}
function squareRoot() {
    if (currentNumber === "") return;

    currentNumber = String(
        Math.sqrt(Number(currentNumber))
    );
    document.getElementById("result").textContent =
        currentNumber;
}
function inverse() {
    if (currentNumber === "") return;

    if (Number(currentNumber) === 0) {
        document.getElementById("result").textContent =
            "ERROR";
        return;
    }
    currentNumber = String(
        1 / Number(currentNumber)
    );

    document.getElementById("result").textContent =
        currentNumber;
}
function showHistory() {
    if (history.length === 0) {
        alert("История пока пустая");
        return;
    }
    alert(
        "История:\n\n" +
        history.join("\n")
    );
}